library(tidyverse)

folder <- sample(c("2020/","2019/1/","cell_lines/"),1)

filename <- paste0(folder, "Assay_", sample(1000,1),".tsv")

tissues <- c("brain","liver","lung","heart","kidney","pancreas","bladder","colon")

genes <- c("ENSG00000168256","ENSG00000100726","ENSG00000162086","ENSG00000185122","ENSG00000180846","ENSG00000152818","ENSG00000198879","ENSG00000115998","ENSG00000132305","ENSG00000153015")

num_tissues <- c(12,13,15,17,19,21)

separator <- sample(c("_V"," replicate","."),1)

tissues_rand <- sample(tissues, sample(num_tissues,1), replace = TRUE) %>% 
  as_tibble() %>% 
  arrange(value) %>% 
  group_by(value) %>% 
  mutate(no=row_number()) %>% 
  unite("tissue",value:no, sep=separator) %>% 
  pull(tissue)

expand_grid(genes=genes, tissue=tissues_rand) %>% 
  rowwise() %>% 
  mutate(expression = sample(1:10000, 1, replace = TRUE)) %>% 
  pivot_wider(values_from = expression, names_from = tissue) %>% 
  write_tsv(filename)
